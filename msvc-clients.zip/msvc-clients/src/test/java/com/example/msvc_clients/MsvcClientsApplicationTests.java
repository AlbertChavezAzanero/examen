package com.example.msvc_clients;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcClientsApplicationTests {

	@Test
	void contextLoads() {
	}

}
