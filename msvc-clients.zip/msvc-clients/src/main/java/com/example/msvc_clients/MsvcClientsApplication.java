package com.example.msvc_clients;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsvcClientsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsvcClientsApplication.class, args);
	}

}
